﻿#ifndef PCH_H
#define PCH_H

#include "framework.h"
#include <string>
#include <vector>
#include <set>
#include <unordered_map>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <stdexcept>
#include <string>
#include <vector>
#include <set>
#include <unordered_map>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <atlconv.h> 

#endif 